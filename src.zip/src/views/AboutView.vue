<template>
  <div>
    <p class="font-bold text-xl">about</p>
  </div>
</template>
<script setup></script>
